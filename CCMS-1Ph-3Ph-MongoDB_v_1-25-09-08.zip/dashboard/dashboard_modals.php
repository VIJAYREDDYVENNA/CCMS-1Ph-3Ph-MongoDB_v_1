<?php
// include("html/open_non_active_devcices.php");
include("html/open_non_active_devcices.php");
include("html/total_devices.php");
include("html/installed_modal.php");
include("html/uninstalled_modal.php");
include("html/poor-network-modal.php");
include("html/active_modal.php");
include("html/power_failure.php");
include("html/faulty_devices.php");
include("html/system-on-modal.php");
include("html/manual-on-modal.php");
include("html/off_modal.php");
include("html/confirmation_modal.php");
include("html/device-current-status_modal.php");
include("html/device-current-status_1ph-modal.php");




?>