 <select class="form-select pointer" id="device_id" name="device_id">
    <?php
    include("device_id_list.php");
    ?>
 </select>