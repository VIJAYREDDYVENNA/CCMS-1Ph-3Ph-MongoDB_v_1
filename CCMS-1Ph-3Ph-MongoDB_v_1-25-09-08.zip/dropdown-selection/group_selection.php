 <select class="form-select pointer" id="group-list" aria-label="Large select example">
  <option value="ALL" >All-Groups/Locations</option>
  <?php
  include("group-list.php");
  ?>
  <!-- <option value="UNGROUPED" >UNGROUPED</option> -->
</select>